<?php
header( 'Location: http://www.hand-interactive.com/m/' ) ;
?>